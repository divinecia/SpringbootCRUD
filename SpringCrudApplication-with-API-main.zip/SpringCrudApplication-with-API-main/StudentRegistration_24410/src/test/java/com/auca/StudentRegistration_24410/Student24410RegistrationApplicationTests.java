package com.auca.StudentRegistration_24410;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Student24410RegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}

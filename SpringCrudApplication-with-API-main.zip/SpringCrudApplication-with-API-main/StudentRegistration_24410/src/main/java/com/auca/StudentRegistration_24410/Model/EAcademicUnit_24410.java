package com.auca.StudentRegistration_24410.Model;

public enum EAcademicUnit_24410 {
        Programme,
        Faculty,
        Department
}

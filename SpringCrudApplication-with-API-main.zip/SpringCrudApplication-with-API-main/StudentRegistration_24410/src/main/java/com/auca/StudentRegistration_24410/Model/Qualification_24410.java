package com.auca.StudentRegistration_24410.Model;

public enum Qualification_24410 {
    Master,
    Phd,
    Professor
}
